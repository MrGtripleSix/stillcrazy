#!/usr/bin/env python3
# ============================================================
# GHOST BREAKER - Main Banner & Menu
# Edit config via ghost_editor.py
# ============================================================

# ============================================================
# CONFIG START - JANGAN HAPUS BARIS INI
TOOL_NAME  = "Ghost-Web-Scanner-V1.0"
POWER      = "Main Menu"
AUTHOR     = "Sneijderlino"
GITHUB     = "github.com/Sneijderlino"
RISK_LVL   = "0% JEBROL"
VERSION    = "v75-MAX"
BANNER_NAME= "GHOST BREAKER"
MENU_ITEMS = [
    "[1] Input Single Target (1 URL)",
    "[2] Input dari File (domain.txt)",
    "[0] Exit",
]
# CONFIG END - JANGAN HAPUS BARIS INI
# ============================================================

import os
import socket
import platform

# Warna
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
BLUE   = "\033[94m"
CYAN   = "\033[96m"
WHITE  = "\033[97m"
ORANGE = "\033[38;5;208m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

def get_sys_info():
    node = platform.node()
    sys  = platform.system()
    return f"{node} ({sys})"

def get_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "Detecting ..."

def print_banner():
    os.system("clear" if os.name == "posix" else "cls")

    logo = [
        f"{RED}{BOLD}        uuuuuuu",
        f"{RED}     uu$$$$$$$$$$$uu",
        f"{RED}   uu$$$$$$$$$$$$$$$$$uu",
        f"{RED}  u$$$$$$$$$$$$$$$$$$$$$u",
        f"{RED} u$$$$$$$$$$$$$$$$$$$$$$$u",
        f"{RED} u$$$$$$$$$$$$$$$$$$$$$$$u",
        f"{RED} u$$$$$$   \"$$$\"   $$$$$$u",
        f"{RED}  \"$$$$\"      u$u       $$$$\"",
        f"{RED}   $$$u       u$u       u$$$",
        f"{RED}   $$$u      u$$$u     u$$$",
        f"{RED}    \"$$$$uu$$$   $$$uu$$$$\"",
        f"{RED}     \"$$$$$$$\"   \"$$$$$$$\"",
        f"{RED}       u$$$$$$$u$$$$$$$u",
        f"{RED}        u$\"$\"$\"$\"$\"$\"$u",
        f"{RED}         \"$u$$u$$u$$u$\"",
        f"{RED}           \"$$$$$$$$$\"{RESET}",
    ]

    info = [
        f"",
        f"",
        f"      {CYAN}{BOLD}{BANNER_NAME} {VERSION}{RESET}",
        f"  {GREEN}{'─'*34}{RESET}",
        f"  {BLUE}Tool Name : {RED}{TOOL_NAME}{RESET}",
        f"  {BLUE}Power     : {GREEN}{POWER}{RESET}",
        f"  {BLUE}Author    : {RED}{AUTHOR}{RESET}",
        f"  {YELLOW}[{GITHUB}]{RESET}",
        f"  {GREEN}{'─'*34}{RESET}",
        f"  {BLUE}RISK LVL  : {YELLOW}{RISK_LVL}{RESET}",
        f"  {BLUE}OS        : {GREEN}{get_sys_info()}{RESET}",
        f"  {BLUE}TARGET    : {ORANGE}Ready{RESET}",
        f"  {BLUE}IP TGT    : {YELLOW}{get_ip()}{RESET}",
        f"",
        f"",
        f"",
    ]

    max_lines = max(len(logo), len(info))
    logo += [""] * (max_lines - len(logo))
    info += [""] * (max_lines - len(info))

    for l, r in zip(logo, info):
        # Strip warna untuk hitung panjang asli
        import re
        clean = re.sub(r'\033\[[0-9;]*m', '', l)
        pad = 40 - len(clean)
        print(f"{l}{' '*pad}{r}")

    print(f"\n{BLUE}[ {ORANGE}KALI LINUX {WHITE}| {BLUE}TERMUX {WHITE}| {CYAN}GOD MODE {VERSION} ACTIVE {BLUE}]{RESET}")
    print(f"{GREEN}{'─'*55}{RESET}\n")

    for item in MENU_ITEMS:
        print(f"  {CYAN}{item}{RESET}")

    print(f"\n{GREEN}{'─'*55}{RESET}")

def main():
    print_banner()
    print()
    choice = input(f"  {YELLOW}Pilih menu: {RESET}").strip()

    if choice == "0":
        print(f"\n{RED}[!] Exiting...{RESET}\n")
        exit()
    elif choice == "1":
        target = input(f"  {CYAN}Masukkan URL target: {RESET}").strip()
        print(f"\n  {GREEN}[+] Target set: {target}{RESET}\n")
        # Tambah logic scan disini
    elif choice == "2":
        fname = input(f"  {CYAN}Masukkan nama file: {RESET}").strip()
        print(f"\n  {GREEN}[+] File: {fname}{RESET}\n")
        # Tambah logic baca file disini
    else:
        print(f"\n  {RED}[!] Menu tidak valid{RESET}\n")

if __name__ == "__main__":
    main()
