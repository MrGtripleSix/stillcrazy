#!/usr/bin/env python3
# ============================================================
# GHOST EDITOR - Editor interaktif untuk ghost_banner.py
# Jalankan: python3 ghost_editor.py
# ============================================================

import os
import re

TARGET_FILE = "ghost_banner.py"

# Warna
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
WHITE  = "\033[97m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

def clear():
    os.system("clear" if os.name == "posix" else "cls")

def read_config():
    """Baca nilai config dari ghost_banner.py"""
    config = {}
    try:
        with open(TARGET_FILE, "r") as f:
            content = f.read()

        # Baca single value
        for key in ["TOOL_NAME", "POWER", "AUTHOR", "GITHUB", "RISK_LVL", "VERSION", "BANNER_NAME"]:
            match = re.search(rf'^{key}\s*=\s*"(.*?)"', content, re.MULTILINE)
            if match:
                config[key] = match.group(1)

        # Baca MENU_ITEMS
        menu_match = re.search(r'MENU_ITEMS\s*=\s*\[(.*?)\]', content, re.DOTALL)
        if menu_match:
            items_raw = menu_match.group(1)
            items = re.findall(r'"(.*?)"', items_raw)
            config["MENU_ITEMS"] = items

    except FileNotFoundError:
        print(f"\n{RED}[!] File {TARGET_FILE} tidak ditemukan!{RESET}")
        print(f"{YELLOW}[!] Pastikan ghost_editor.py satu folder dengan ghost_banner.py{RESET}\n")
        exit()

    return config

def write_config(config):
    """Tulis ulang config ke ghost_banner.py"""
    with open(TARGET_FILE, "r") as f:
        content = f.read()

    # Update single values
    for key in ["TOOL_NAME", "POWER", "AUTHOR", "GITHUB", "RISK_LVL", "VERSION", "BANNER_NAME"]:
        if key in config:
            content = re.sub(
                rf'^({key}\s*=\s*)".*?"',
                f'\\g<1>"{config[key]}"',
                content,
                flags=re.MULTILINE
            )

    # Update MENU_ITEMS
    if "MENU_ITEMS" in config:
        items_str = "[\n"
        for item in config["MENU_ITEMS"]:
            items_str += f'    "{item}",\n'
        items_str += "]"
        content = re.sub(
            r'MENU_ITEMS\s*=\s*\[.*?\]',
            f'MENU_ITEMS = {items_str}',
            content,
            flags=re.DOTALL
        )

    with open(TARGET_FILE, "w") as f:
        f.write(content)

    print(f"\n{GREEN}[✓] Config berhasil disimpan ke {TARGET_FILE}!{RESET}")

def print_header():
    clear()
    print(f"{CYAN}{BOLD}")
    print(f"  ╔══════════════════════════════════════╗")
    print(f"  ║       GHOST BREAKER - EDITOR         ║")
    print(f"  ║   Editor interaktif ghost_banner.py  ║")
    print(f"  ╚══════════════════════════════════════╝{RESET}\n")

def show_current(config):
    print(f"{YELLOW}  [Config saat ini]{RESET}")
    print(f"  {WHITE}{'─'*40}{RESET}")
    keys = ["TOOL_NAME", "POWER", "AUTHOR", "GITHUB", "RISK_LVL", "VERSION", "BANNER_NAME"]
    for i, key in enumerate(keys, 1):
        print(f"  {CYAN}[{i}] {key:<12}{RESET}: {GREEN}{config.get(key, '-')}{RESET}")
    print(f"  {CYAN}[8] MENU_ITEMS{RESET}")
    print(f"  {WHITE}{'─'*40}{RESET}")

    if "MENU_ITEMS" in config:
        print(f"\n  {YELLOW}[Menu saat ini]{RESET}")
        for i, item in enumerate(config["MENU_ITEMS"], 1):
            print(f"    {CYAN}{i}.{RESET} {item}")

def edit_single(config, key, label):
    print(f"\n  {YELLOW}Edit {label}{RESET}")
    print(f"  Nilai sekarang: {GREEN}{config.get(key, '-')}{RESET}")
    new_val = input(f"  Nilai baru (Enter = skip): ").strip()
    if new_val:
        config[key] = new_val
        print(f"  {GREEN}[✓] {label} diubah ke: {new_val}{RESET}")
    else:
        print(f"  {YELLOW}[~] Tidak ada perubahan{RESET}")
    return config

def edit_menu(config):
    clear()
    print_header()
    print(f"\n  {YELLOW}[Edit Menu Items]{RESET}")
    print(f"  {WHITE}{'─'*40}{RESET}")

    items = config.get("MENU_ITEMS", [])
    for i, item in enumerate(items, 1):
        print(f"  {CYAN}[{i}]{RESET} {item}")

    print(f"\n  {WHITE}Pilihan:{RESET}")
    print(f"  {CYAN}[A]{RESET} Tambah menu baru")
    print(f"  {CYAN}[E]{RESET} Edit menu yang ada")
    print(f"  {CYAN}[D]{RESET} Hapus menu")
    print(f"  {CYAN}[0]{RESET} Kembali")

    choice = input(f"\n  {YELLOW}Pilih: {RESET}").strip().upper()

    if choice == "A":
        new_item = input(f"  {CYAN}Teks menu baru: {RESET}").strip()
        if new_item:
            items.append(new_item)
            print(f"  {GREEN}[✓] Menu ditambahkan!{RESET}")

    elif choice == "E":
        try:
            idx = int(input(f"  {CYAN}Nomor menu yang diedit: {RESET}")) - 1
            if 0 <= idx < len(items):
                print(f"  Sekarang: {GREEN}{items[idx]}{RESET}")
                new_val = input(f"  Nilai baru: ").strip()
                if new_val:
                    items[idx] = new_val
                    print(f"  {GREEN}[✓] Menu diupdate!{RESET}")
            else:
                print(f"  {RED}[!] Nomor tidak valid{RESET}")
        except ValueError:
            print(f"  {RED}[!] Input harus angka{RESET}")

    elif choice == "D":
        try:
            idx = int(input(f"  {CYAN}Nomor menu yang dihapus: {RESET}")) - 1
            if 0 <= idx < len(items):
                removed = items.pop(idx)
                print(f"  {GREEN}[✓] Menu '{removed}' dihapus!{RESET}")
            else:
                print(f"  {RED}[!] Nomor tidak valid{RESET}")
        except ValueError:
            print(f"  {RED}[!] Input harus angka{RESET}")

    config["MENU_ITEMS"] = items
    return config

def main():
    config = read_config()

    while True:
        print_header()
        show_current(config)

        print(f"\n  {WHITE}Pilihan:{RESET}")
        print(f"  {CYAN}[1-7]{RESET} Edit field config")
        print(f"  {CYAN}[8]  {RESET} Edit menu items")
        print(f"  {CYAN}[S]  {RESET} Simpan perubahan")
        print(f"  {CYAN}[R]  {RESET} Reload dari file")
        print(f"  {CYAN}[0]  {RESET} Keluar tanpa simpan")

        choice = input(f"\n  {YELLOW}Pilih: {RESET}").strip().upper()

        keys = ["TOOL_NAME", "POWER", "AUTHOR", "GITHUB", "RISK_LVL", "VERSION", "BANNER_NAME"]
        labels = ["Tool Name", "Power/Mode", "Author", "Github", "Risk Level", "Version", "Banner Name"]

        if choice.isdigit() and 1 <= int(choice) <= 7:
            idx = int(choice) - 1
            config = edit_single(config, keys[idx], labels[idx])
            input(f"\n  {WHITE}[Enter untuk lanjut]{RESET}")

        elif choice == "8":
            config = edit_menu(config)
            input(f"\n  {WHITE}[Enter untuk lanjut]{RESET}")

        elif choice == "S":
            write_config(config)
            input(f"\n  {WHITE}[Enter untuk lanjut]{RESET}")

        elif choice == "R":
            config = read_config()
            print(f"  {GREEN}[✓] Config direload dari file!{RESET}")
            input(f"\n  {WHITE}[Enter untuk lanjut]{RESET}")

        elif choice == "0":
            print(f"\n  {YELLOW}[!] Keluar tanpa menyimpan...{RESET}\n")
            break

        else:
            print(f"\n  {RED}[!] Pilihan tidak valid{RESET}")
            input(f"\n  {WHITE}[Enter untuk lanjut]{RESET}")

if __name__ == "__main__":
    main()
